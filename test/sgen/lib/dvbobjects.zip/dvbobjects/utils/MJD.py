#! /usr/bin/env python

# This file is part of the dvbobjects library.
# 
# Copyright © 2005 Lorenzo Pallara
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from math import floor

def MJD_convert(year, month, day):

	if (month == 1) or (month == 2):
	    l = 1
	else:
	    l = 0
	return 14956 + day + (floor((year - l) * 365.25)) + (floor((month + 1 + l * 12) * 30.6001))



# 53 -> 0x53
def bcd_8bit(num):
	return (num/10) << 4 | (num % 10)

# 1 -> 0x1
# 12 -> 0x12
# 123 -> 0x123 
# ...
def GetBCD(num) :
    digits = [int(c) for c in str(num)]
    shift = (len(digits) - 1) * 4

    out = 0
    for i in digits :
        out = (i << shift) | out
        shift -= 4 
        
    return out 
