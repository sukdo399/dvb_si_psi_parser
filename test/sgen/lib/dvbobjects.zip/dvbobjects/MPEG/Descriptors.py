#! /usr/bin/env python

#
# Copyright (C) 2004  Lorenzo Pallara, lpallara@cineca.it
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#                                  
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#                                  
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


import string
from dvbobjects.utils import *
from dvbobjects.MPEG.Descriptor import Descriptor


######################################################################
class video_stream_descriptor(Descriptor):

    descriptor_tag = 0x2
    
    def bytes(self):
	if self.MPEG_1_only_flag == 0:
	    fmt = "!BBB"
	    return pack(fmt,
		(self.multiple_frame_rate_flag & 0x1) << 7 | 
		(self.frame_rate_code & 0xF) << 3 | 
		(self.MPEG_1_only_flag & 0x1) << 2 | 
		(self.constrained_parameter_flag & 0x1) << 1 | 
		(self.still_picture_flag & 0x1),
		self.profile_and_level_indication,
		(self.chroma_format & 0x3) << 6 | 
		(self.frame_rate_extension_flag & 0x1) << 5 |
		0x1F,
	    )
	else :
	    fmt = "!B"
	    return pack(fmt,
		(self.multiple_frame_rate_flag & 0x1) << 7 |
		(self.frame_rate_code & 0xF) << 3 |
		(self.MPEG_1_only_flag & 0x1) << 2 |
		(self.constrained_parameter_flag & 0x1) << 1 |
		(self.still_picture_flag & 0x1),
	    )						    

######################################################################
class audio_stream_descriptor(Descriptor):

    descriptor_tag = 0x3
    
    def bytes(self):
	fmt = "!B"
	return pack(fmt,
		(self.free_format_flag & 0x1) << 7 |
		(self.ID & 0x1) << 6 |
		(self.layer & 0x3) << 4 |
		(self.variable_rate_audio_indicator & 0x1) << 3,
	)



######################################################################
class hierarchy_descriptor(Descriptor):
    descriptor_tag = 0x4
    
    def bytes(self):
	fmt = "!BBBB"
	return pack(fmt,
		(self.hicrarchy_type & 0x0f),
		(self.hierarchy_layer_index & 0x3f),
		(self.hierarchy_embedded_layer_index & 0x3f),
		(self.hierarchy_channel & 0x3f),
	)

######################################################################
class data_stream_alignment_descriptor(Descriptor):
    descriptor_tag = 0x6
    
    def bytes(self):
	fmt = "!B"
	return pack(fmt,
		self.alignment_type,
	)	


######################################################################
class target_background_grid_descriptor(Descriptor):
    descriptor_tag = 0x7
    
    def bytes(self):
	fmt = "!BBBB"
	return pack(fmt,
		(self.horizontal_size & 0x3FC0) >> 6,
		(self.horizontal_size & 0x3F) << 2 |
		(self.vertical_size & 0x3000) >> 8,
		(self.vertical_size & 0xff0) >> 4,
		(self.vertical_size & 0xf) << 4 |
		(self.aspect_ratio_information & 0xff),
	)		


######################################################################
######################################################################
class video_window_descriptor(Descriptor):
    descriptor_tag = 0x8
    
    def bytes(self):
	fmt = "!BBBB"
	return pack(fmt,
		(self.horizontal_offset & 0x3FC0) >> 6,
		(self.horizontal_offset & 0x3F) << 2 |
		(self.vertical_offset & 0x3000) >> 8,
		(self.vertical_offset & 0xff0) >> 4,
		(self.vertical_offset & 0xf) << 4 |
		(self.window_priority & 0xff),
	)		


######################################################################
class system_clock_descriptor(Descriptor):
    descriptor_tag = 0x0B # 11
    
    def bytes(self):
	fmt = "!BB"
	return pack(fmt,
		(self.external_clock_referrence_indicator & 0x01) << 7 |
		(self.clock_accuracy_integer & 0x3f),
		(self.clock_accuracy_exponent & 0x07) << 5,
	)	


######################################################################
class multiplex_buffer_utilization_descriptor(Descriptor):
    descriptor_tag = 0x0C # 12
    
    def bytes(self):
	fmt = "!HH"
	return pack(fmt,
		(self.bound_valid_flag & 0x01) << 15 |
		(self.LTW_offset_lower_bound & 0x7FFF),
		(self.LTW_offset_upper_bound & 0x7FFF),
	)	


######################################################################
class copyright_descriptor(Descriptor):
    descriptor_tag = 0x0D # 13
    
    def bytes(self):
	fmt = "!L%ds" % (len(self.additional_copyright_info))
	return pack(fmt,
		self.copyright_identifier,
		self.additional_copyright_info,
	)	


######################################################################
class maximum_bitrate_descriptor(Descriptor):
    descriptor_tag = 0x0E # 14
    
    def bytes(self):
	fmt = "!BBB"
	return pack(fmt,
		(self.maximum_bitrate & 0x3F0000) >> 16,
		(self.maximum_bitrate & 0xFF00) >> 8,
		(self.maximum_bitrate & 0xFF),
	)	


######################################################################
class private_data_indicator_descriptor(Descriptor):
    descriptor_tag = 0x0F # 15
    
    def bytes(self):
	fmt = "!L"
	return pack(fmt,
		self.private_data_indicator,
	)	

######################################################################
class smoothing_buffer_descriptor(Descriptor):
    descriptor_tag = 0x10 # 16
    
    def bytes(self):
	fmt = "!BBBBBB"
	return pack(fmt,
		(self.sb_leak_rate & 0x3F0000) >> 16,
		(self.sb_leak_rate & 0xFF00) >> 8,
		(self.sb_leak_rate & 0xFF),
		(self.sb_size & 0x3F0000) >> 16,
		(self.sb_size & 0xFF00) >> 8,
		(self.sb_size & 0xFF),
	)	


######################################################################
class STD_descriptor(Descriptor):

    descriptor_tag = 0x11 # 17

    def bytes(self):
        fmt = "!B"
        return pack(fmt,
                    0xFE | self.leal_valid_flag,
                    )
		    
######################################################################
class ibp_descriptor(Descriptor):
    descriptor_tag = 0x12 # 18
    
    def bytes(self):
	fmt = "!BB"
	return pack(fmt,
		(self.close_gop_flag & 0x01) << 7 |
		(self.identical_gop_flag & 0x01) << 6 |
		(self.max_gop_length & 0x3f00) >> 8,
		(self.max_gop_length & 0xff),
	)	


######################################################################
class mpeg4_video_descriptor(Descriptor):
    descriptor_tag = 0x1B # 27
    
    def bytes(self):
	fmt = "!B"
	return pack(fmt,
		self.mpeg4_visual_profile_and_level
	)	


######################################################################
class mpeg4_audio_descriptor(Descriptor):
    descriptor_tag = 0x1C # 28
    
    def bytes(self):
	fmt = "!B"
	return pack(fmt,
		self.mpeg4_audio_profile_and_level
	)	


######################################################################
class iod_descriptor(Descriptor):
    descriptor_tag = 0x1D # 29
    
    def bytes(self):
	fmt = "!BBB"
	return pack(fmt,
		self.scope_of_IOD_label,
		self.IOD_label,
		self.InitialObjectDescriptor #7.2.6.4 of ISO/IEC 14496-1
	)	

######################################################################
class sl_descriptor(Descriptor):
    descriptor_tag = 0x1E # 30
    
    def bytes(self):
	fmt = "!H"
	return pack(fmt,
		self.ES_ID,
	)


######################################################################
class fmc_loop_item(DVBobject):

    def pack(self):
    
	fmt = "!HB"
	return pack(fmt,
	    self.ES_ID,
	    self.FlexMuxChannel,
	)


class fmc_descriptor(Descriptor):
    descriptor_tag = 0x1f # 31
    
    def bytes(self):
	item_bytes = string.join(
	    map(lambda x: x.pack(),	
                self.fmc_loop),
            "")	  

	fmt = "!%ds" % len(item_bytes)
	return pack(fmt,
		item_bytes,
	)

######################################################################
class external_es_id_descriptor(Descriptor):
    descriptor_tag = 0x20 # 32
    
    def bytes(self):
	fmt = "!H"
	return pack(fmt,
		self.External_ES_ID,
	)


######################################################################
class MuxCodeTableEntry(DVBobject):

	# Just dummy... refer to 7.4.2.5 of 14496-1    
    def pack(self):
    
	fmt = "!B"
	return pack(fmt,
	    self.dummy,		# Need to implement...
	)


class muxcode_descriptor(Descriptor):
    descriptor_tag = 0x21 # 33

	
    def bytes(self):
	item_bytes = string.join(
	    map(lambda x: x.pack(),	
                self.muxcode_loop),
            "")	  

	fmt = "!%ds" % len(item_bytes)
	return pack(fmt,
		item_bytes,
	)
  

######################################################################
class FlexMuxBufferDescriptor(DVBobject):
   
    def pack(self):
    
	    # Just dummy...  
		fmt = "!B"
		return pack(fmt,
		    self.dummy,		# Need to implement...
		)



class fmxbuffersize_descriptor(Descriptor):
	descriptor_tag = 0x22 # 34

	def bytes(self):
	
		item_bytes = string.join(
		    map(lambda x: x.pack(),	
	                self.fmxbuffersize_loop),
	            "")	  

		self.DefaultFlexMuxBufferDescriptor = 0x01	# dummy
		
		fmt = "!B%ds" % len(item_bytes)
		return pack(fmt,
			DefaultFlexMuxBufferDescriptor,
			item_bytes,
		)
  

######################################################################
class multiplexbuffer_descriptor(Descriptor):
    descriptor_tag = 0x22 # 34

    def bytes(self):
		fmt = "!BBBBBB"
		return pack(fmt,
			(self.MB_buffer_size & 0xFF0000) >> 16,
			(self.MB_buffer_size & 0xFF00) >> 8,
			(self.MB_buffer_size & 0xFF),
			(self.TB_leak_rate & 0xFF0000) >> 16,
			(self.TB_leak_rate & 0xFF00) >> 8,
			(self.TB_leak_rate & 0xFF),
		)
######################################################################

class association_tag_descriptor(Descriptor):

    descriptor_tag = 0x14

    def bytes(self):
	if self.use == 0:
    	    fmt = "!HHBLL%ds" % (len(self.private_data))
    	    return pack(fmt,    
		    self.association_tag,
		    self.use,
		    self.selector_lenght,
		    self.transaction_id,
		    self.timeout,
		    self.private_data,		    
                    )		
	else:
    	    fmt = "!HHB%ds%ds" % (
		    len(self.selector_lenght), 
		    len(self.privatedata)
		    )	    
	    return pack(fmt,
                    self.association_tag,
		    self.use,
		    self.selector_lenght,
		    self.selector_bytes,
		    self.privatedata,
		    )

######################################################################
class graphics_constraints_descriptor(Descriptor):

    descriptor_tag = 0x14
    
    def bytes(self):
	gc_bytes = string.join(
	map(lambda byte, self=self: pack("!B", byte),
		self.graphics_configuration_bytes),
		"")
		
	fmt = "!B%ds" % (len(gc_bytes))
	return pack(fmt,
		0xF8 |
		(self.can_run_without_visible_ui << 2) |
		(self.handles_configuration_changed << 1) |
		(self.handles_externally_controlled_video),
		gc_bytes,
	)

######################################################################
class DTS_registration_descriptor(Descriptor):

    descriptor_tag = 0x05

    def bytes (self):
	fmt = "!%ds" % (len(self.format_identifier))
	return pack(fmt, self.format_identifier)

######################################################################
class carousel_identifier_descriptor(Descriptor):

    descriptor_tag = 0x13

    def bytes(self):
	if self.format_ID:
        	fmt = "!LBBHHHBLBB%ds%ds" % (len(self.object_key_data) , len(self.private_data))
        	return pack(fmt,
    			self.carousel_ID,
	        	self.format_ID,
			self.module_version,
			self.module_ID,
			self.block_size,
			self.module_size,
			self.compression_method,
			self.original_size,
			self.timeout,
			len(self.object_key_data),
			self.object_key_data,
			self.private_data,
			)
	else :
                fmt = "!LB%ds" % (len(self.private_data))
                return pack(fmt,
                        self.carousel_ID,
                        self.format_ID,
                        self.private_data,
                        )
			
######################################################################							
class ca_descriptor(Descriptor):

    descriptor_tag = 0x9
    
    def bytes(self):
        fmt = "!HH"
        return pack(fmt,
            self.CA_system_ID,
            0xE000 | (self.CA_PID & 0x1FFF),
        )
        
